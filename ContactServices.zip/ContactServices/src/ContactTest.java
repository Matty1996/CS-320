import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


public class ContactTest {

	@Test
	public void testGetters() {
		Contact contact = new Contact("01234567891", "First", "Last", "7085067895", "Address 9648" );
				

        assertEquals("124", contact.getContactID());
        assertEquals("Matt", contact.getFirstName());
        assertEquals("Kakareko", contact.getLastName());
        assertEquals("7085062787", contact.getPhoneNumber());
        assertEquals("9648 west fullerton, Elgin, 60164", contact.getAddress());
        
      
	}

}
