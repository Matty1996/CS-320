import java.util.Map;
import java.util.HashMap;

public class ContactService {
	private Map <String, Contact> contacts;
	
	public void ContactSevice() 
	{
		contacts = new HashMap<>();
	}
	
	public void addContact(Contact contact) {
		if (contact != null && !contacts.containsKey(contact.getContactID() )) 
		{
			contacts.put(contact.getContactID(), contact);
		}
	}
	
	public void deleteContact(String contactID) 
	{
		contacts.remove(contactID);
	}
	
	public void updateContact(String contactID, String contactPropery, String contactPropertyInfo)
	{
		Contact contact = contacts.get(contactID);
		
		if (contact != null) {
			switch (contactPropery) {
				
			case "lastName":
				contact.setLastName(contactPropertyInfo);
				break;
				
			case "firstName":
				contact.setFirstName(contactPropertyInfo);
				break;
				
			case "phoneNumber":
				contact.setPhoneNumber(contactPropertyInfo);
				break;
				
			case "address":
				contact.setAddress(contactPropertyInfo);
				break;
				
			default :
				throw new IllegalArgumentException("Input information correctly");
			}
		}
	}
	
	public Contact getContact(String contactID) {
		return contacts.get(contactID);
	}
}
