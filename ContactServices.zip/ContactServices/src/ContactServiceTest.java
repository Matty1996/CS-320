import org.junit.jupiter.api.Assertions;
import org.junit.Before;
import org.junit.jupiter.api.Test;

	public class ContactServiceTest {
		private ContactService contactService;
		
		@Before
		public void setup() 
		{
			 contactService = new ContactService();
		}
		
		@Test
		public void contactServiceTest() {
			
			Contact contact = new Contact("0123456789", "First", "Last", "0123456789", "Address");
			contactService.addContact(contact);
	        Contact retrievedContact = contactService.getContact("0123456789");
	        Assertions.assertEquals(contact, retrievedContact);
	        
	        contactService.deleteContact("0123456789");
	        retrievedContact = contactService.getContact("0123456789");
	        Assertions.assertNull(retrievedContact);
	        
	        contactService.updateContact("0123456789", "address", "9648 West Mont, Elgin IL 60164");
			retrievedContact = contactService.getContact("0123456789");
			Assertions.assertEquals("address", retrievedContact.getAddress());
		}
	

	

}
