import static org.junit.jupiter.api.Assertions.*;
import org.junit.*;
import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.assertEquals;

public class TaskTest {
	@Test
	public void createValidTask() {
		Task task = new Task("Name", "Description", "1");
		Assert.assertEquals("Name", task.getName());
		Assert.assertEquals("Description", task.getDescription());
		Assert.assertEquals("1", task.getTaskID());
	}
}
