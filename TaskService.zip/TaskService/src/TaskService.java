import java.util.*;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
	private final Map<String, Task> tasks;

	
	public TaskService() {
		this.tasks = new HashMap<>();
	}
	
	public void taskDelete(String taskID) {
		tasks.remove(taskID);
	}
	public void taskAdd(Task task) {
		tasks.put(task.getTaskID(), task);
		}
		
	public void updateTaskDescription(String updatedDescription, String taskID) {
	        Task task = tasks.get(taskID);
	        if (task != null) {
	            task.setDescription(updatedDescription);
	        }
	    }
	public void taskNameUpdate(String updatedName, String taskID) {
		 Task task = tasks.get(taskID);
			if (task != null) {
				task.setName(updatedName);	
			}
			}
	
	public Task getTask(String taskID) {
	     return tasks.get(taskID);
	    }	
	}

