import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.*;

public class TaskServiceTest {
	private TaskService taskService;

	@Before
	public void setup() {
		TaskService taskService = new TaskService();
	}
	
	@Test
	public void deleteTaskTest() {
		TaskService taskService = new TaskService();
		Task task = new Task("Name", "Description", "1");
		taskService.taskAdd(task);
		taskService.taskDelete("1");
		assertNull(taskService.getTask("1"));
	}
	
	@Test
	public void addTaskTest() {
		TaskService taskService = new TaskService();
		Task task = new Task("Name", "Description", "1");
		taskService.taskAdd(task);
		assertEquals(task, taskService.getTask("1"));
	}
	
	@Test
	public void updateTaskNameTest() {
	    TaskService taskService = new TaskService();
	    Task task = new Task("Name", "Description", "1");
	    taskService.taskAdd(task);
	    taskService.taskNameUpdate("changed task name", "1");
	    assertEquals("changed task name", taskService.getTask("1").getName());
	    }

	 
}
