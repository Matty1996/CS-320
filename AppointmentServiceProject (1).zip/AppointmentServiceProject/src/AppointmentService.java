import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	private final Map<String, Appointment> appointments;
	
	public AppointmentService() {
		appointments = new HashMap<>();
	}
	public void deleteAppointment(String appointmentID) {
		appointments.remove(appointmentID);
	}		
	public void addAppointment(Appointment appointment) {
		appointments.put(appointment.getAppointmentID(),appointment);
	}	
}
