import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;


public class AppointmentTest {

	@Test
	public void testAppointementGetters() {
		Date newAppointmentDate = new Date();
		Appointment appointment = new Appointment("Description", newAppointmentDate, "1112345");		
				
		assertEquals("Description testing", appointment.getAppointmentDescription());
		assertEquals(newAppointmentDate, appointment.getAppointmentDate());
		assertEquals("1112345", appointment.getAppointmentID());		
	}
}
