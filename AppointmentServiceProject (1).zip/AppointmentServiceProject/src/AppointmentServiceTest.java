import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
	private AppointmentService appointmentService;	
	@Before
	public void setUpTest() {
		appointmentService = new AppointmentService();
		}

	@Test
	public void testAppointementGetters() {
		Date newAppointmentDate = new Date();
		Appointment appointment = new Appointment("Description", newAppointmentDate, "1112345");		
		
		appointmentService.addAppointment(appointment);
		}
	
	 @Test
	    public void deleteAppointmentTest() {
		 Date newAppointmentDate = new Date();
			Appointment newAppointment = new Appointment("Description", newAppointmentDate, "1112345");			
	        
	        appointmentService.addAppointment(newAppointment);
	        appointmentService.deleteAppointment("1112345");
	        
	    }

}
