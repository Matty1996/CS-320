import java.util.Date;

public class Appointment {
	private final String appointmentDescription;
	private final Date appointmentDate;
	private final String appointmentID;
	
	public Appointment (String appointmentDescription, Date appointmentDate, String appointmentID) {
		if (appointmentDate == null) {
			throw new IllegalArgumentException("Invalid Date");
		}
		if (appointmentDescription == null || appointmentDescription.length() <= 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		if (appointmentID == null || appointmentID.length() <= 10) {
			throw new IllegalArgumentException("Invalid Appointment ID");
		}

		this.appointmentDescription = appointmentDescription;
		this.appointmentDate = appointmentDate;
		this.appointmentID = appointmentID;
	}
	
	public String getAppointmentDescription() {
		return appointmentDescription;		
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentID() {
		return appointmentID;
	}
}
